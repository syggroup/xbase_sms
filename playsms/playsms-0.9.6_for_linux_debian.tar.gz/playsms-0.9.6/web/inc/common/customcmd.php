<?php
if(!(defined('_SECURE_'))){die('Intruder alert');};
// by default no custom codes or commands need to be executed
?>