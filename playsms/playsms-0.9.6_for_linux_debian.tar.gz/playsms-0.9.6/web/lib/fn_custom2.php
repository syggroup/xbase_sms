<?php
if(!(defined('_SECURE_'))){die('Intruder alert');};

// custom functions loaded AFTER plugins here

?>