<?php

if(!(defined('_SECURE_'))){die('Intruder alert');};

include $apps_path['themes']."/".$themes_module."/config.php";
include $apps_path['themes']."/".$themes_module."/fn.php";
?>