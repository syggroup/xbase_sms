<?php if(!(defined('_SECURE_'))){die('Intruder alert');}; ?>
<?php include $apps_path['themes']."/".$themes_module."/header.php"; ?>
<?php echo $error_content; ?>
<?php include $apps_path['themes']."/".$themes_module."/footer.php"; ?>
