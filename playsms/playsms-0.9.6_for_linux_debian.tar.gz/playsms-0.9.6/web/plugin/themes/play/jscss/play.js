$(function(){

  $('.button')
    .addClass('btn');

});
