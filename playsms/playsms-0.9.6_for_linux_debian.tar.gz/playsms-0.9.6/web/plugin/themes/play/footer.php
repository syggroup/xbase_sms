            </div> <!-- main -->
          </div> <!-- span-two-third -->
        </div> <!-- row -->
      </div> <!-- content -->
      <footer>
      <p><?php echo $theme_play_foot1; ?></p>
      </footer>
    
    </div> <!-- /container -->
    <script type="text/javascript"
	    src="<?php echo $http_path['themes']; ?>/<?php echo $themes_module; ?>/jscss/play.js"></script>
  </body>
</html>

