<?php
if(!(defined('_SECURE_'))){die('Intruder alert');};

/*

// custom functions for this theme
function themes_default_set_title($title) {
}

function themes_default_get_title() {
}

*/

?>