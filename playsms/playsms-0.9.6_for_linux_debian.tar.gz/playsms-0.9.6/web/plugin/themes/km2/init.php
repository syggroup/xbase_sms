<?php
include $apps_path['themes']."/".$themes_module."/config.php";
include $apps_path['themes']."/".$themes_module."/fn.php";
?>