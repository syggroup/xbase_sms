<?php if(!(defined('_SECURE_'))){die('Intruder alert');}; ?>
<?php
// insert to left menu array
$arr_menu['Tools'][] = array("index.php?app=menu&inc=tools_sendfromfile&op=list", "Send from file");
?>