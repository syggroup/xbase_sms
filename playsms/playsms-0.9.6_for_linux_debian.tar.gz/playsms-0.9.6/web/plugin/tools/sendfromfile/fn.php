<?php if(!(defined('_SECURE_'))){die('Intruder alert');}; ?>
<?php
// empty
?>