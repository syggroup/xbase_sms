<?php if(!(defined('_SECURE_'))){die('Intruder alert');}; ?>
<?php
if(!valid()){forcenoaccess();};

// empty

?>